import btree from '../src'
import with2 from './with2'
import with3 from './with3'
import with4 from './with4'
import with5 from './with5'
// import with9 from './with9'
// import withN from './withN'
import withFP from './withFP'
// with2()
// with3()
// with4()
// with5()
// with9()
// withN()
withFP()

