export const initTree = {
    firstNoneLeaf: null,
    comparatorSortFx: null,
    size: 0,
    countIdLeaf: 0,
    countIdNoneLeaf: 0,
    noneLeafMax: 3,
    leafMax: 3,
    // first: 0,
    // last: null,
    noneLeafs: {},
    // 0: {
    //     blocks: [store[i]],
    //     parent: null,
    //     arrayPointers: {
    //         p0: '',
    //         p1: ''
    //     },
    //     type: 'noneleaf'
    // }
    leafs: {
        // 0: {
        //     blocks: [store[i]],
        //     parent: null,
        //     next: null,
        //     back: null,
        //     type: 'leaf'
        // }
    },
    store: {
        // key: {
        // key,
        // value
    }
}