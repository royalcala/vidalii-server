require('@vidalii/db/modules/index.test')(
    { pathToInputs: __dirname + '/input' }
)