module.exports = {
    url: {
        local: 'http://admin:admin@localhost:4000',
        remote: 'http://admin:admin@localhost:5984'
    }
}