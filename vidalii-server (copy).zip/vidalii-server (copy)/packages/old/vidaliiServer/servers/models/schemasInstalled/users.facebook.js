const { string, int, custom } = require('@vidalii/db/schemas/valuesTypes')
module.exports = {
    schema: {
        nameFacebook: string
    }
}