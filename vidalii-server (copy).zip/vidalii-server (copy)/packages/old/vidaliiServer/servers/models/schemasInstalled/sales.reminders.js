const { string, int, custom } = require('@vidalii/db/schemas/valuesTypes')
module.exports = {
    schema: {
        day: string
    }
}