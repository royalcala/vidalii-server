var correct = {
    "ok": true,
    "id": "00901810-a116-43fc-ac76-9644835fae94",
    "rev": "3-fd0b5aa97ef80853259c54e9edd4221e"
}

var errorRev = {
    "error": "conflict",
    "reason": "Document update conflict"
}
