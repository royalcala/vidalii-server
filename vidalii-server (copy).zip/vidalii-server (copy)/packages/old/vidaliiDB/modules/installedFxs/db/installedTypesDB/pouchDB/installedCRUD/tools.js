module.exports = ({ db }) => () => ({
    ...db
})