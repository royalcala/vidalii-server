// const validationFxs = require('./readInstalled')(__dirname + '/installedFxs')

module.exports = () => {
    // console.log('validationFxs::',validationFxs)
    return ''
}