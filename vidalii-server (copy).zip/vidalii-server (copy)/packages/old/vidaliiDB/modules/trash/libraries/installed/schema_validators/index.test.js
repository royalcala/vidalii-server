// const validationFxs = require('./readInstalled')(__dirname + '/installedFxs')

describe("schema_validators", () => {

    require('./installed/updateDoc/index.test.js')


})

