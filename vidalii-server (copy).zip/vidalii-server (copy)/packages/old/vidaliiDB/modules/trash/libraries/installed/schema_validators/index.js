const validationFxs = require('./readInstalled')(__dirname + '/installed')

module.exports = validationFxs
