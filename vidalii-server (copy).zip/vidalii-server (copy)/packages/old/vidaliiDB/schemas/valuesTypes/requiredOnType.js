module.exports = {
    isNodeType: true
}