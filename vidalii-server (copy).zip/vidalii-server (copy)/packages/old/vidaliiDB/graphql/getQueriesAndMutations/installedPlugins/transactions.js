const transactions = require('../../../shared/model.transactions')


module.exports = transactions